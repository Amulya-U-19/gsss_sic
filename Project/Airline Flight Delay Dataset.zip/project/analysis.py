import pandas as pd

# --- 1. Load dataset ---
df = pd.read_csv("data/flights.csv", sep=",")

# Strip whitespace from column names
df.columns = df.columns.str.strip()

# --- 2. Explore ---
print("\n--- First 5 Rows ---")
print(df.head())

print("\n--- Info ---")
df.info()  # don't wrap with print()

print("\n--- Describe ---")
print(df.describe())

# --- 3. Data cleaning / type conversion ---
df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
df['DepartureDelay'] = pd.to_numeric(df['DepartureDelay'], errors='coerce').fillna(0)
df['ArrivalDelay'] = pd.to_numeric(df['ArrivalDelay'], errors='coerce').fillna(0)
df = df.dropna(subset=['Date'])  # remove invalid dates

# --- 4. Filtering Operations ---
delayed_30 = df[df['ArrivalDelay'] > 30]
from_JFK = df[df['OriginAirport'] == 'JFK']
delta_flights = df[df['Airline'] == 'Delta']

print("\nFlights delayed > 30 mins:\n", delayed_30.head())
print("\nFlights from JFK:\n", from_JFK.head())
print("\nFlights by Delta:\n", delta_flights.head())

# --- 5. Grouping Operations ---
# 5.1 By Airline
airline_summary = df.groupby('Airline').agg(
    AverageArrivalDelay=('ArrivalDelay', 'mean'),
    AverageDepartureDelay=('DepartureDelay', 'mean'),
    TotalFlights=('Airline', 'size')  # safer than FlightID
).reset_index()

# 5.2 By OriginAirport
airport_summary = df.groupby('OriginAirport').agg(
    TotalFlights=('OriginAirport', 'size'),
    DelayedFlights=('ArrivalDelay', lambda x: (x > 30).sum())
).reset_index()
airport_summary['PercentDelayed'] = (
    airport_summary['DelayedFlights'] / airport_summary['TotalFlights']
).replace([float("inf")], 0).round(2)
airport_summary.drop(columns=['DelayedFlights'], inplace=True)

# 5.3 By Date
daily_summary = df.groupby('Date').agg(
    AverageArrivalDelay=('ArrivalDelay', 'mean'),
    TotalFlights=('Airline', 'size')
).reset_index()

# 5.4 By Route
route_summary = df.groupby(['OriginAirport', 'DestinationAirport']).agg(
    AverageArrivalDelay=('ArrivalDelay', 'mean'),
    TotalFlights=('OriginAirport', 'size')
).reset_index()

# --- 6. Export summaries ---
airline_summary.to_csv('airline_summary.csv', index=False)
airport_summary.to_csv('airport_summary.csv', index=False)
route_summary.to_csv('route_summary.csv', index=False)

print("\n--- Summaries exported successfully! ---")
