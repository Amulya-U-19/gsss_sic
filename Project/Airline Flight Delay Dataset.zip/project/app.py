from flask import Flask, render_template, request, send_file, jsonify
import pandas as pd
from io import BytesIO, StringIO
import os

app = Flask(__name__)

# ---------- Load dataset (use flights.csv in same folder) ----------
CSV_PATH = "data/flights.csv"
if os.path.exists(CSV_PATH):
    df = pd.read_csv(CSV_PATH)
else:
    # fallback sample so app won't crash while you test
    sample = [
        {"FlightID": "AF001", "Airline": "Delta", "OriginAirport": "JFK", "DestinationAirport": "LAX", "Date": "2023-01-05", "DepartureDelay": 15, "ArrivalDelay": 1},
        {"FlightID": "F002", "Airline": "United", "OriginAirport": "ORD", "DestinationAirport": "SFO", "Date": "2023-01-05", "DepartureDelay": 45, "ArrivalDelay": 5},
        {"FlightID": "F003", "Airline": "Delta", "OriginAirport": "ATL", "DestinationAirport": "MIA", "Date": "2023-01-06", "DepartureDelay": -5, "ArrivalDelay": 0},
        {"FlightID": "F004", "Airline": "American", "OriginAirport": "DFW", "DestinationAirport": "LAX", "Date": "2023-01-06", "DepartureDelay": 60, "ArrivalDelay": 5},
        {"FlightID": "F005", "Airline": "Southwest", "OriginAirport": "LAX", "DestinationAirport": "LAS", "Date": "2023-01-07", "DepartureDelay": 10, "ArrivalDelay": 5},
    ]
    df = pd.DataFrame(sample)

# normalize column names
df.columns = df.columns.str.strip()

# ensure required columns exist
for c in ["Airline", "OriginAirport", "DestinationAirport", "Date", "DepartureDelay", "ArrivalDelay"]:
    if c not in df.columns:
        if c in ("DepartureDelay", "ArrivalDelay"):
            df[c] = 0
        else:
            df[c] = ""

# convert types
df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
df["DepartureDelay"] = pd.to_numeric(df["DepartureDelay"], errors="coerce").fillna(0)
df["ArrivalDelay"] = pd.to_numeric(df["ArrivalDelay"], errors="coerce").fillna(0)

# helper: choices for dropdowns
def _choices(series):
    return sorted([str(x).strip() for x in series.dropna().unique() if str(x).strip()])

AIRLINES = _choices(df["Airline"])
ORIGINS = _choices(df["OriginAirport"])


# compute summary helper (used for both view and download)
def compute_summary(option: str, airline_filter: str = None, origin_filter: str = None, top_n_routes: int = None) -> pd.DataFrame:
    base = df.copy()

    # apply filters (case-insensitive)
    if airline_filter:
        base = base[base["Airline"].astype(str).str.strip().str.casefold() == str(airline_filter).strip().casefold()]
    if origin_filter:
        base = base[base["OriginAirport"].astype(str).str.strip().str.casefold() == str(origin_filter).strip().casefold()]

    if option == "airline":
        res = base.groupby("Airline", dropna=False).agg(
            AverageArrivalDelay=("ArrivalDelay", "mean"),
            TotalFlights=("Airline", "size")
        ).reset_index()
        res["AverageArrivalDelay"] = res["AverageArrivalDelay"].round(2)

    elif option == "airport":
        temp = base.groupby("OriginAirport", dropna=False).agg(
            TotalFlights=("OriginAirport", "size"),
            DelayedFlights=("ArrivalDelay", lambda x: (x > 30).sum())
        ).reset_index()
        temp["PercentDelayed"] = ((temp["DelayedFlights"] / temp["TotalFlights"]) * 100).fillna(0).round(2)
        res = temp.drop(columns=["DelayedFlights"])

    elif option == "date":
        # group by date string for stable display
        base["DateStr"] = base["Date"].dt.strftime("%Y-%m-%d")
        res = base.groupby("DateStr", dropna=False).agg(
            AverageArrivalDelay=("ArrivalDelay", "mean"),
            TotalFlights=("Airline", "size")
        ).reset_index().rename(columns={"DateStr": "Date"})
        res["AverageArrivalDelay"] = res["AverageArrivalDelay"].round(2)

    elif option == "route":
        temp = base.copy()
        temp["OriginAirport"] = temp["OriginAirport"].astype(str).str.strip()
        temp["DestinationAirport"] = temp["DestinationAirport"].astype(str).str.strip()
        res = temp.groupby(["OriginAirport", "DestinationAirport"], dropna=False).agg(
            AverageArrivalDelay=("ArrivalDelay", "mean"),
            TotalFlights=("OriginAirport", "size")
        ).reset_index()
        res["AverageArrivalDelay"] = res["AverageArrivalDelay"].round(2)
        if top_n_routes:
            res = res.sort_values("AverageArrivalDelay", ascending=False).head(int(top_n_routes))

    else:
        raise ValueError("Invalid option")

    return res


@app.route("/", methods=["GET", "POST"])
def index():
    records = []
    columns = []
    operation = None

    if request.method == "POST":
        choice = request.form.get("choice")

        # Filtering choices
        if choice == "delayed":
            result_df = df[df["ArrivalDelay"] > 30].reset_index(drop=True)
            operation = "Flights delayed more than 30 minutes"

        elif choice == "filter_airline":
            airline = request.form.get("value")
            result_df = df[df["Airline"].astype(str).str.strip().str.casefold() == str(airline).strip().casefold()].reset_index(drop=True)
            operation = f"Flights by Airline: {airline}"

        elif choice == "filter_origin":
            origin = request.form.get("value")
            result_df = df[df["OriginAirport"].astype(str).str.strip().str.casefold() == str(origin).strip().casefold()].reset_index(drop=True)
            operation = f"Flights from Origin Airport: {origin}"

        # Grouping choices
        elif choice == "group_airline":
            result_df = compute_summary("airline")
            operation = "Grouped by Airline → Average Delay & Total Flights"

        elif choice == "group_airport":
            result_df = compute_summary("airport")
            operation = "Grouped by OriginAirport → Total Flights & % Delayed"

        elif choice == "group_date":
            result_df = compute_summary("date")
            operation = "Grouped by Date → Daily Average Delay"

        elif choice == "group_route":
            result_df = compute_summary("route", top_n_routes=5)
            operation = "Top 5 Routes with Highest Average Delay"

        else:
            result_df = pd.DataFrame()

        # Prepare for template: convert datetimes to strings and build records/columns
        if not result_df.empty:
            # convert datetime columns to readable strings
            for col in result_df.select_dtypes(include=["datetime64[ns]"]).columns:
                result_df[col] = result_df[col].dt.strftime("%Y-%m-%d")
            # Round numeric floats for neatness
            for col in result_df.select_dtypes(include=["float", "float64"]).columns:
                result_df[col] = result_df[col].round(2)
            columns = result_df.columns.tolist()
            # convert NaN to empty string to avoid "nan" display
            result_df = result_df.fillna("")
            records = result_df.to_dict(orient="records")
        else:
            columns = []
            records = []

    return render_template(
        "index.html",
        airlines=AIRLINES,
        origins=ORIGINS,
        columns=columns,
        records=records,
        operation=operation
    )


# Optional: download endpoints for grouped summaries
@app.route("/download/<summary_type>")
def download(summary_type):
    if summary_type not in ("airline", "airport", "date", "route"):
        return jsonify({"error": "invalid summary type"}), 400

    if summary_type == "route":
        df_summary = compute_summary("route", top_n_routes=None)  # full route summary
    else:
        df_summary = compute_summary(summary_type)

    buf = StringIO()
    df_summary.to_csv(buf, index=False)
    buf.seek(0)
    return send_file(
        BytesIO(buf.getvalue().encode("utf-8")),
        mimetype="text/csv",
        as_attachment=True,
        download_name=f"{summary_type}_summary.csv"
    )


if __name__ == "__main__":
    app.run(debug=True)
